from flask import Flask, request
import requests
import os

app = Flask(__name__)

@app.route('/alert', methods=['POST'])
def alert():
    data = request.json
    summary = data['alerts'][0]['annotations']['summary']
    create_jira_ticket(summary)
    return '', 200

def create_jira_ticket(summary):
    jira_url = os.getenv('JIRA_URL') + '/rest/api/2/issue'
    auth = (os.getenv('JIRA_USER'), os.getenv('JIRA_TOKEN'))
    json_data = {
        "fields": {
            "project": {"key": os.getenv('PROJECT_KEY')},
            "summary": summary,
            "description": summary,
            "issuetype": {"name": "Task"}
        }
    }
    requests.post(jira_url, auth=auth, json=json_data)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)